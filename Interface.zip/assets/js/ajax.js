//$(document).ready(function(e){
	//$("#menuTopo a").click(function(e){
//		e.preventDefault();
//		var href = $(this).attr('href');
//		$(".menu").load(href + " .menu");
//		$(".conteudo").load(href + " .conteudo");
//		$(".carrossel").load(href + " .carrossel");
 //});



$(document).ready(function(e){
	$(".tudo").click(function(e){
		e.preventDefault();
		var href = $(this).attr('href');
		$(".carrossel").load(href + " .carrossel");
		$(".menu").load(href + " .menu");
		$(".conteudo").load(href + " .conteudo");
	});
	$(".login").click(function(e){
		e.preventDefault();
		var href = $(this).attr('href');
		$(".conteudo").load(href + " .conteudo");
		$(".menu").load(href + " .menu");
		$(" .carrossel").hide();
	});
	$(".links").click(function(e){
		e.preventDefault();
		var href = $(this).attr('href');
		$(".conteudo").load(href + " .conteudo");
		$(".menu").load(href + " .menu");
		$(" .carrossel").hide();
	});
	$(".cadastro").click(function(e){
		e.preventDefault();
		var href = $(this).attr('href');
		$(".conteudo").load(href + " .conteudo");
		$(".menu").load(href + " .menu");
		$(" .carrossel").hide();
	});
	$(".inicio").click(function(e){
		e.preventDefault();
		var href = $(this).attr('href');
		$(".tudo").load(href + " .tudo");
		$(".menu").load(href + " .menu");
		$(".carrossel").show();
	});
});
