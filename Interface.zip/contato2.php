<?php
    require 'init.php';
?>
<form action="add.php" method="post" enctype="multipart/form-data">
								
									<input type="text" name="txtNome">
													
									<input type="text" name="txtEmail">
												
									<input type="text" name="txtComentario"><br>
									<input type="submit" >
</form>	